def greeting(you:str):
    print(f"Welcome {you}")
    return 1

def something(you:str):
    print(f"I don't know what to type.")
    return f"{you}"