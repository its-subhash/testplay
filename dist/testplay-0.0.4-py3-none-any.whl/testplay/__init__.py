from functionality.functionality import *
from other_functionality.other_functionality import *


if __name__=="__main__":
    greeting("Darsh")
    something("Darsh")
    print(summ(1,2))
    print(mull(2,4))
