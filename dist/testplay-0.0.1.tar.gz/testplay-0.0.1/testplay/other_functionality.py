def summ(a,b):
    return a+b

def mull(a,b):
    return a*b